﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev_THW03_ATM_Bank_Jefferson_WL
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
            dt.Columns.Add("Name");
            dt.Columns.Add("Password");
            dt.Columns.Add("Balance");
        }

        int angkaUrutan = 0;
        string rupiah;
        int balance;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonlogin_Click(object sender, EventArgs e)
        {
            bool verified = false;
            for(int i = 0; i< dt.Rows.Count; i++)
            {
                if(textBoxuser.Text.ToString() == dt.Rows[i]["Name"].ToString() && textBoxpass.Text.ToString() == dt.Rows[i]["Password"].ToString())
                {
                    verified = true;
                    angkaUrutan = i;
                    break;
                }
                else
                {
                    verified = false;
                }
            }

            if(verified == true)
            {
                MessageBox.Show("Login Success");
                panel_login.Visible = false;
                panel_deposit.Visible = false;
                panel_withdraw.Visible = false;
                panel_balance.Visible = true;
                textBoxuser.Clear();
                textBoxpass.Clear();
                balance = Convert.ToInt32(dt.Rows[angkaUrutan]["Balance"]);
                rupiah = "Rp. " + string.Format("{0:n}", balance);
                lbl_balance.Text = rupiah;
                lbl_balance_withdraw.Text = rupiah;
            }
            else
            {
                MessageBox.Show("Login Failed User Not Found");
                textBoxuser.Clear();
                textBoxpass.Clear();
            }
         
        }


        private void buttonregister_Click(object sender, EventArgs e)
        {
            int count = 0;
            bool same = false;

            if(textBoxuser.Text == "" || textBoxpass.Text == "")
            {
                MessageBox.Show("Register Failed Input still blank");
            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (textBoxuser.Text.ToString() == dt.Rows[i][0].ToString())
                    {
                        same = true;
                    }
                    else
                    {
                        same = false;
                    }
                }
                if (same == true)
                {
                    textBoxuser.Clear();
                    textBoxpass.Clear();
                    MessageBox.Show("Register Failed User duplicate");
                }
                else
                {
                    dt.Rows.Add(textBoxuser.Text.ToString(), textBoxpass.Text.ToString(), 0);
                    textBoxuser.Clear();
                    textBoxpass.Clear();
                    MessageBox.Show("Register Success");
                }
            }
        }

        private void btn_to_deposit_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_deposit.Visible = true;
            panel_withdraw.Visible = false;
            panel_balance.Visible = false;
        }

        private void btn_to_withdraw_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_deposit.Visible = false;
            panel_withdraw.Visible = true;
            panel_balance.Visible = false;
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            if(Convert.ToInt32(textBox_deposit.Text) <= 0)
            {
                MessageBox.Show("Gaboleh 0 yaa");
            }
            else
            {
                dt.Rows[angkaUrutan]["Balance"] = Convert.ToInt32(dt.Rows[angkaUrutan]["Balance"]) + Convert.ToInt32(textBox_deposit.Text);
                panel_login.Visible = false;
                panel_deposit.Visible = false;
                panel_withdraw.Visible = false;
                panel_balance.Visible = true;
                balance = Convert.ToInt32(dt.Rows[angkaUrutan]["Balance"]);
                rupiah = "Rp. " + string.Format("{0:n}", balance);
                lbl_balance.Text = rupiah;
                lbl_balance_withdraw.Text = rupiah;
                textBox_deposit.Clear();
            }
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            if(Convert.ToInt32(textBox_withdraw.Text) > Convert.ToInt32(dt.Rows[angkaUrutan]["Balance"]))
            {
                MessageBox.Show("Saldonya Kurang bang");
            }
            else
            {
                dt.Rows[angkaUrutan]["Balance"] = Convert.ToInt32(dt.Rows[angkaUrutan]["Balance"]) - Convert.ToInt32(textBox_withdraw.Text);
                panel_login.Visible = false;
                panel_deposit.Visible = false;
                panel_withdraw.Visible = false;
                panel_balance.Visible = true;
                balance = Convert.ToInt32(dt.Rows[angkaUrutan]["Balance"]);
                rupiah = "Rp. " + string.Format("{0:n}", balance);
                lbl_balance.Text = rupiah;
                lbl_balance_withdraw.Text = rupiah;
                textBox_withdraw.Clear();
            }
        }

        private void btn_logout_deposit_Click_1(object sender, EventArgs e)
        {
            angkaUrutan = 0;
            panel_login.Visible = true;
            panel_deposit.Visible = false;
            panel_withdraw.Visible = false;
            panel_balance.Visible = false;
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            angkaUrutan = 0;
            panel_login.Visible = true;
            panel_deposit.Visible = false;
            panel_withdraw.Visible = false;
            panel_balance.Visible = false;
        }

        private void btn_logout_withdraw_Click(object sender, EventArgs e)
        {
            angkaUrutan = 0;
            panel_login.Visible = true;
            panel_deposit.Visible = false;
            panel_withdraw.Visible = false;
            panel_balance.Visible = false;
        }
    }
}
