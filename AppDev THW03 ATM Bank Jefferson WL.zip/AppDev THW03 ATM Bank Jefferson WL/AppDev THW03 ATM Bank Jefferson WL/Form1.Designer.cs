﻿namespace AppDev_THW03_ATM_Bank_Jefferson_WL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_login = new System.Windows.Forms.Panel();
            this.buttonregister = new System.Windows.Forms.Button();
            this.buttonlogin = new System.Windows.Forms.Button();
            this.textBoxpass = new System.Windows.Forms.TextBox();
            this.textBoxuser = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelucbank = new System.Windows.Forms.Label();
            this.panel_balance = new System.Windows.Forms.Panel();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_to_withdraw = new System.Windows.Forms.Button();
            this.btn_to_deposit = new System.Windows.Forms.Button();
            this.btn_logout = new System.Windows.Forms.Button();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.textBox_deposit = new System.Windows.Forms.TextBox();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_logout_deposit = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.textBox_withdraw = new System.Windows.Forms.TextBox();
            this.lbl_balance_withdraw = new System.Windows.Forms.Label();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.btn_logout_withdraw = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel_login.SuspendLayout();
            this.panel_balance.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_login
            // 
            this.panel_login.Controls.Add(this.buttonregister);
            this.panel_login.Controls.Add(this.buttonlogin);
            this.panel_login.Controls.Add(this.textBoxpass);
            this.panel_login.Controls.Add(this.textBoxuser);
            this.panel_login.Controls.Add(this.label2);
            this.panel_login.Controls.Add(this.label1);
            this.panel_login.Controls.Add(this.labelucbank);
            this.panel_login.Location = new System.Drawing.Point(204, 59);
            this.panel_login.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(322, 284);
            this.panel_login.TabIndex = 8;
            // 
            // buttonregister
            // 
            this.buttonregister.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonregister.Location = new System.Drawing.Point(124, 233);
            this.buttonregister.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonregister.Name = "buttonregister";
            this.buttonregister.Size = new System.Drawing.Size(89, 21);
            this.buttonregister.TabIndex = 14;
            this.buttonregister.Text = "Register";
            this.buttonregister.UseVisualStyleBackColor = true;
            this.buttonregister.Click += new System.EventHandler(this.buttonregister_Click);
            // 
            // buttonlogin
            // 
            this.buttonlogin.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonlogin.Location = new System.Drawing.Point(124, 197);
            this.buttonlogin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonlogin.Name = "buttonlogin";
            this.buttonlogin.Size = new System.Drawing.Size(89, 24);
            this.buttonlogin.TabIndex = 13;
            this.buttonlogin.Text = "Login";
            this.buttonlogin.UseVisualStyleBackColor = true;
            this.buttonlogin.Click += new System.EventHandler(this.buttonlogin_Click);
            // 
            // textBoxpass
            // 
            this.textBoxpass.Location = new System.Drawing.Point(136, 152);
            this.textBoxpass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxpass.Name = "textBoxpass";
            this.textBoxpass.Size = new System.Drawing.Size(109, 20);
            this.textBoxpass.TabIndex = 12;
            // 
            // textBoxuser
            // 
            this.textBoxuser.Location = new System.Drawing.Point(136, 128);
            this.textBoxuser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxuser.Name = "textBoxuser";
            this.textBoxuser.Size = new System.Drawing.Size(109, 20);
            this.textBoxuser.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(66, 152);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "Password :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(66, 131);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Username :";
            // 
            // labelucbank
            // 
            this.labelucbank.AutoSize = true;
            this.labelucbank.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelucbank.Location = new System.Drawing.Point(118, 28);
            this.labelucbank.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelucbank.Name = "labelucbank";
            this.labelucbank.Size = new System.Drawing.Size(122, 34);
            this.labelucbank.TabIndex = 8;
            this.labelucbank.Text = "UC Bank";
            // 
            // panel_balance
            // 
            this.panel_balance.Controls.Add(this.lbl_balance);
            this.panel_balance.Controls.Add(this.label4);
            this.panel_balance.Controls.Add(this.label5);
            this.panel_balance.Controls.Add(this.btn_to_withdraw);
            this.panel_balance.Controls.Add(this.btn_to_deposit);
            this.panel_balance.Controls.Add(this.btn_logout);
            this.panel_balance.Location = new System.Drawing.Point(208, 60);
            this.panel_balance.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel_balance.Name = "panel_balance";
            this.panel_balance.Size = new System.Drawing.Size(313, 284);
            this.panel_balance.TabIndex = 9;
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Location = new System.Drawing.Point(124, 172);
            this.lbl_balance.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(48, 13);
            this.lbl_balance.TabIndex = 13;
            this.lbl_balance.Text = "Rp. 0,00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(55, 169);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Balance";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(77, 27);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 34);
            this.label5.TabIndex = 11;
            this.label5.Text = "UC Bank";
            // 
            // btn_to_withdraw
            // 
            this.btn_to_withdraw.Location = new System.Drawing.Point(98, 235);
            this.btn_to_withdraw.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_to_withdraw.Name = "btn_to_withdraw";
            this.btn_to_withdraw.Size = new System.Drawing.Size(72, 23);
            this.btn_to_withdraw.TabIndex = 10;
            this.btn_to_withdraw.Text = "Withdraw";
            this.btn_to_withdraw.UseVisualStyleBackColor = true;
            this.btn_to_withdraw.Click += new System.EventHandler(this.btn_to_withdraw_Click);
            // 
            // btn_to_deposit
            // 
            this.btn_to_deposit.Location = new System.Drawing.Point(98, 209);
            this.btn_to_deposit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_to_deposit.Name = "btn_to_deposit";
            this.btn_to_deposit.Size = new System.Drawing.Size(72, 21);
            this.btn_to_deposit.TabIndex = 9;
            this.btn_to_deposit.Text = "Deposit";
            this.btn_to_deposit.UseVisualStyleBackColor = true;
            this.btn_to_deposit.Click += new System.EventHandler(this.btn_to_deposit_Click);
            // 
            // btn_logout
            // 
            this.btn_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.Location = new System.Drawing.Point(198, 80);
            this.btn_logout.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(59, 22);
            this.btn_logout.TabIndex = 8;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.textBox_deposit);
            this.panel_deposit.Controls.Add(this.btn_deposit);
            this.panel_deposit.Controls.Add(this.btn_logout_deposit);
            this.panel_deposit.Controls.Add(this.label6);
            this.panel_deposit.Controls.Add(this.label7);
            this.panel_deposit.Location = new System.Drawing.Point(204, 59);
            this.panel_deposit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(310, 283);
            this.panel_deposit.TabIndex = 9;
            // 
            // textBox_deposit
            // 
            this.textBox_deposit.Location = new System.Drawing.Point(72, 197);
            this.textBox_deposit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_deposit.Name = "textBox_deposit";
            this.textBox_deposit.Size = new System.Drawing.Size(94, 20);
            this.textBox_deposit.TabIndex = 9;
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(89, 229);
            this.btn_deposit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(59, 20);
            this.btn_deposit.TabIndex = 8;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_logout_deposit
            // 
            this.btn_logout_deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout_deposit.Location = new System.Drawing.Point(188, 88);
            this.btn_logout_deposit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_logout_deposit.Name = "btn_logout_deposit";
            this.btn_logout_deposit.Size = new System.Drawing.Size(59, 22);
            this.btn_logout_deposit.TabIndex = 7;
            this.btn_logout_deposit.Text = "Log Out";
            this.btn_logout_deposit.UseVisualStyleBackColor = true;
            this.btn_logout_deposit.Click += new System.EventHandler(this.btn_logout_deposit_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(64, 171);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Input Deposit Amount :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(66, 35);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 34);
            this.label7.TabIndex = 5;
            this.label7.Text = "UC Bank";
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.textBox_withdraw);
            this.panel_withdraw.Controls.Add(this.lbl_balance_withdraw);
            this.panel_withdraw.Controls.Add(this.btn_withdraw);
            this.panel_withdraw.Controls.Add(this.btn_logout_withdraw);
            this.panel_withdraw.Controls.Add(this.label9);
            this.panel_withdraw.Controls.Add(this.label10);
            this.panel_withdraw.Controls.Add(this.label11);
            this.panel_withdraw.Location = new System.Drawing.Point(208, 66);
            this.panel_withdraw.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(308, 281);
            this.panel_withdraw.TabIndex = 9;
            // 
            // textBox_withdraw
            // 
            this.textBox_withdraw.Location = new System.Drawing.Point(88, 207);
            this.textBox_withdraw.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_withdraw.Name = "textBox_withdraw";
            this.textBox_withdraw.Size = new System.Drawing.Size(94, 20);
            this.textBox_withdraw.TabIndex = 13;
            // 
            // lbl_balance_withdraw
            // 
            this.lbl_balance_withdraw.AutoSize = true;
            this.lbl_balance_withdraw.Location = new System.Drawing.Point(118, 141);
            this.lbl_balance_withdraw.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_balance_withdraw.Name = "lbl_balance_withdraw";
            this.lbl_balance_withdraw.Size = new System.Drawing.Size(48, 13);
            this.lbl_balance_withdraw.TabIndex = 12;
            this.lbl_balance_withdraw.Text = "Rp. 0,00";
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_withdraw.Location = new System.Drawing.Point(105, 238);
            this.btn_withdraw.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(56, 19);
            this.btn_withdraw.TabIndex = 11;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // btn_logout_withdraw
            // 
            this.btn_logout_withdraw.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout_withdraw.Location = new System.Drawing.Point(190, 77);
            this.btn_logout_withdraw.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_logout_withdraw.Name = "btn_logout_withdraw";
            this.btn_logout_withdraw.Size = new System.Drawing.Size(62, 20);
            this.btn_logout_withdraw.TabIndex = 10;
            this.btn_logout_withdraw.Text = "Log Out";
            this.btn_logout_withdraw.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(66, 181);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(151, 16);
            this.label9.TabIndex = 9;
            this.label9.Text = "Input Withdrawal Amount :\r\n";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(40, 141);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 16);
            this.label10.TabIndex = 8;
            this.label10.Text = "Balance";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(74, 24);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 34);
            this.label11.TabIndex = 7;
            this.label11.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 444);
            this.Controls.Add(this.panel_login);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.panel_balance);
            this.Controls.Add(this.panel_withdraw);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.panel_balance.ResumeLayout(false);
            this.panel_balance.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Button buttonregister;
        private System.Windows.Forms.Button buttonlogin;
        private System.Windows.Forms.TextBox textBoxpass;
        private System.Windows.Forms.TextBox textBoxuser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelucbank;
        private System.Windows.Forms.Panel panel_balance;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_to_withdraw;
        private System.Windows.Forms.Button btn_to_deposit;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.TextBox textBox_deposit;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Button btn_logout_deposit;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.TextBox textBox_withdraw;
        private System.Windows.Forms.Label lbl_balance_withdraw;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Button btn_logout_withdraw;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}

